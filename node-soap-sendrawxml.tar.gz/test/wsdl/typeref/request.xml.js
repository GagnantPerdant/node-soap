module.exports = '<ns1:orderRq xmlns:ns1="http://example.org/ns1" xmlns="http://example.org/ns1">' +
  '<ns1:itemRq><ns1:ecomRq><ns2:rqUID xmlns:ns2="http://example.org/ns2">001</ns2:rqUID>' +
  '</ns1:ecomRq><ns1:item><qty>100</qty>' +
  '<ns2:itemId xmlns:ns2="http://example.org/ns2">item01</ns2:itemId></ns1:item>' +
  '<ns2:backupItem xmlns:ns2="http://example.org/ns2"><qty>50</qty>' +
  '<ns2:itemId>item02</ns2:itemId></ns2:backupItem></ns1:itemRq></ns1:orderRq>';
